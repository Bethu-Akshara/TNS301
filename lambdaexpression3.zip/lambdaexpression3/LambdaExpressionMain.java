package com.tnsif.day6.lambdaexpression3;

public class LambdaExpressionMain {
	
	
	public static void main(String[] args) {
		Addable a1 = (a,b)->(a+b);
		System.out.println(a1.add(10, 20));	
			
		};
	}


