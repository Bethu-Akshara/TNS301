package com.tnsif.day5.finall.classs;

public final class A {
	
	public void display() {
		
		System.out.println("Display parent class conetnts");
		
		
	}

}
