package com.tnsif.day5.finall.classs;

public class B extends A {

	public static void main(String[] args) {
	

	}

}
