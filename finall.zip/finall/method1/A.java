package com.tnsif.day5.finall.method1;

public class A {
	
	public final void display() {
		
		System.out.println("Parent class display");
		
	}

}
