package com.tnsif.day6.lambdaexpression2;

public interface Sayable {
	
	public String say(String name);

}
