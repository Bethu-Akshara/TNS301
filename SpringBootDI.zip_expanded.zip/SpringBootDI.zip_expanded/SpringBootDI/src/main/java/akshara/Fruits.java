package akshara;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

@Component("fruits")
public class Fruits {

	

	public static void main(String[] args) {
			// TODO Auto-generated method stub
			ConfigurableApplicationContext context =  SpringApplication.run(Fruits.class, args);
			
	   Mango m =context.getBean(Mango.class);
	
	   
	   m.display();
		}
	

}
