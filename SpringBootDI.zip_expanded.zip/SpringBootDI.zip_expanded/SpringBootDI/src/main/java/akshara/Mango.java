package akshara;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("mango")
public class Mango {
	public void yellow()
	{
		System.out.println("mango is yellow");
	
	}
	public void display() 
	{}
@Autowired
public Banana ana;
@Autowired
public Mango ango;
@Autowired
public Apple ple;


}
