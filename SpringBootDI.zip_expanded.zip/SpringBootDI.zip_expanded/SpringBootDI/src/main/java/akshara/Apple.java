package akshara;

import org.springframework.stereotype.Component;

@Component("apple")
public class Apple {
	public void red()
	{
		System.out.println("the apple is red");
	}

}
