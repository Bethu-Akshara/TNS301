package akshara;

import org.springframework.stereotype.Component;

@Component("banana")
public class Banana {
	public void white()
	{
		System.out.println("the banana is white");
	}

}
