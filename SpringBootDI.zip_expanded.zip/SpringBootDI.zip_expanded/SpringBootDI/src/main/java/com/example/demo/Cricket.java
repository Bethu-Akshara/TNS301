package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class Cricket {
	
	public void score() {
		System.out.println("Scores we are upadting !!!");
	}

}
