package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class Zomato {
	
	public void Food() {
		System.out.println("U r order is on d way");
	}

}
