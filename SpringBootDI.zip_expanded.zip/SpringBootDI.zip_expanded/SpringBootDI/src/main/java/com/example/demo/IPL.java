package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class IPL {
	
	public void Updates() {
		System.out.println("2024 IPL Teams and Schdule is updating!");
	}

}
