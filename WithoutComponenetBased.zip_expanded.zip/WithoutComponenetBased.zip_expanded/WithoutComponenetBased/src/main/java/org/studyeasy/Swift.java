package org.studyeasy;

import org.studyeasy.interfaces.Car;

public class Swift implements Car {
	
	public String specs() {
		return "Hatchback from suzuki";
	}

}
