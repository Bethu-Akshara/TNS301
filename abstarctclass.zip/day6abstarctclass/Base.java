package com.tnsif.day6abstarctclass;

public abstract class Base {
	
	abstract void fun();

}
