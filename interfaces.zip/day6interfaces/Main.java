package com.tnsif.day6interfaces;

public class Main {
	
	public static void main(String[] args) {
		Pet p1 = new Dog();
		p1.test();
	}

}
