package com.tnsif.day6interfaces;

public interface Pet {
	
	public void test();

}
