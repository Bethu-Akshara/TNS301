package com.tnsif.day5.packages.package3;

import com.tnsif.day5.packages.package1.*;
import com.tnsif.day5.packages.package2.*;

public class Main {
	
	public static void main(String[] args) {
		A a1= new A();
		B b1 = new B();
		C c1 = new C();
		
		a1.displayA();
		b1.displayB();
		c1.displayC();
		
	}

}
