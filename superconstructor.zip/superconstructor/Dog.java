package com.tnsif.day5.superconstructor;

public class Dog extends Animal {
	
	Dog(){
		super();
		System.out.println("Dog is created");
	}

}
